<?php

namespace AilesDuZerix;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\scheduler\TaskScheduler;
use pocketmine\scheduler\Task;

class Main extends PluginBase implements Listener{
	
	public $players = [];
	private $config = [];
	
	public function onEnable()
	{
		$this->getLogger()->info("Ailes par antokiller21)");
		$df = $this->getDataFolder();
		@mkdir($df);
		if(!is_file($df . "config.yml")){
			$cfg = new Config($df . "config.yml", Config::YAML);
			$cfg->setAll([
				"temps" => 3,
				"temps-2" => 4
			]);
			$cfg->save();
		}
		$this->config = (new Config($df . "config.yml", Config::YAML))->getAll();
		$this->getScheduler()->scheduleRepeatingTask(new Zerix($this), $this->config["temps"]);
		$this->getScheduler()->scheduleRepeatingTask(new Zerix2($this), $this->config["temps-2"]);
	}
	
	public function onCommand(CommandSender $sender, Command $command, string $label, array $params) : bool
	{
		$player = $sender;
		if(!$sender instanceof Player){
			$sender->sendMessage("§cCette commande vous est indisponible!");
			return false;
		}
		$username = strtolower($sender->getName());
		if($command->getName() == "ailes"){
			if(isset($this->players[$username])){
				unset($this->players[$username]);
				$sender->sendMessage("§6Volcania §f>> Ailesdésactivé");
				return true;
			}else{
				$this->players[$username] = true;
				$sender->sendMessage("§6Volcania §f>> Ailesactivé");
				return true;
			}
		}else{
			return false;
		}
	}
	
}
